
const produtos = [
  {
    id: 1,
    nome: "Tênis Esportivo",
    preco: 199.99,
    imagem: "https://via.placeholder.com/200?text=T%C3%AAnis",
  },
  {
    id: 2,
    nome: "Fone Bluetooth",
    preco: 149.99,
    imagem: "https://via.placeholder.com/200?text=Fone",
  },
  {
    id: 3,
    nome: "Camiseta Estampada",
    preco: 79.9,
    imagem: "https://via.placeholder.com/200?text=Camiseta",
  },
];

const container = document.getElementById("produtos");
const carrinho = [];

produtos.forEach((produto) => {
  const div = document.createElement("div");
  div.className = "produto";
  div.innerHTML = \`
    <img src="\${produto.imagem}" alt="\${produto.nome}">
    <h3>\${produto.nome}</h3>
    <p>R$ \${produto.preco.toFixed(2)}</p>
    <button onclick='adicionarCarrinho(\${JSON.stringify(produto)})'>Comprar</button>
  \`;
  container.appendChild(div);
});

function adicionarCarrinho(produto) {
  carrinho.push(produto);
  atualizarCarrinho();
}

function atualizarCarrinho() {
  const ul = document.getElementById("itens-carrinho");
  ul.innerHTML = "";
  carrinho.forEach((item) => {
    const li = document.createElement("li");
    li.textContent = \`\${item.nome} - R$ \${item.preco.toFixed(2)}\`;
    ul.appendChild(li);
  });
}

document.getElementById("finalizar").onclick = () => {
  if (carrinho.length === 0) {
    alert("Carrinho vazio!");
  } else {
    const nomes = carrinho.map((p) => p.nome).join(", ");
    alert("Pedido realizado com sucesso! Produtos: " + nomes);
    carrinho.length = 0;
    atualizarCarrinho();
  }
};
